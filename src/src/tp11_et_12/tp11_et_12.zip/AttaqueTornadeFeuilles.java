package tp11_et_12;

public class AttaqueTornadeFeuilles extends AttaqueSpeciale {

    public AttaqueTornadeFeuilles() {
        super("Tornade de feuilles", new String[]{"Plante"}, 65, 90, 10);
    }
}
