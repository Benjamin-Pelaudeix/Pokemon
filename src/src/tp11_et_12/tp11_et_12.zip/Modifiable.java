package tp11_et_12;

public interface Modifiable {
    public void modifier();
}
