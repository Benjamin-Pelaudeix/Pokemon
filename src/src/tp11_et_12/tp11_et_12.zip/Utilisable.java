package tp11_et_12;

public interface Utilisable {
    public void utiliser(Joueur joueur, int indexPokemon);
}
