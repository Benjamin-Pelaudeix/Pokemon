package tp11_et_12;

public interface ChangerItems {
    void changer(Modifiable item);
}
